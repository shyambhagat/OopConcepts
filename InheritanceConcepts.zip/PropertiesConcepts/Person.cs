﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesConcepts
{
    internal class Person
    {
        //Simple Property
        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        // Auto Implemented Property
        public string LastName { get; set; }

        // WriteOnly
        private string logMessage;

        public string LogMessage
        {
            set { logMessage = value; } 
        }

        public double Cash { get; }

        public double Width { get; set; }
        public double Height { get; set; }

        public double Area
        {
            get { return Width * Height; } // Calculated property
        }
    }
}
