﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceConcepts
{
    internal sealed class ATM : IDeposit, IWithdrawal
    {
        public int GetCash()
        {
            return 0;
        }

        public void Deposit(int accountId, double amount)
        {

        }

        public void CompleteWithdraw(int accountId, double amount)
        {
            //throw new NotImplementedException();
        }

        public void Withdraw(int accountId, double amount)
        {
            //throw new NotImplementedException();
        }
    }
}
