﻿// See https://aka.ms/new-console-template for more information

using InheritanceConcepts;

Console.WriteLine("Hello, World!");

//var bank = new Bank();
var branch = new Branch();
