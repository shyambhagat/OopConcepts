﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceConcepts
{
    internal abstract class Bank
    {
        private double BankBalance { get; set; }
        public string BankName { get; set; }

        
        public void ShowBankDetails()
        {
            Console.WriteLine($"{BankName}");
        }

        protected double GetBankBalance()
        {
            return BankBalance;
        }
    }
}
