﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceConcepts
{
    internal class Branch : Bank
    {

        public void PerformOperations()
        {
            var balance = GetBankBalance();
        }
    }
}
