﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceConcepts
{
    internal interface IWithdrawal
    {
        public void Withdraw(int accountId, double amount);
        public void CompleteWithdraw(int accountId, double amount);
    }
}
