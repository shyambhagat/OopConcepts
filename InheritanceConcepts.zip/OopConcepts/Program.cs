﻿// See https://aka.ms/new-console-template for more information

using OopConcepts;

Console.WriteLine("Hello, World!");

var vashiBranch = new Bank();

vashiBranch.BankName = "State Bank";
vashiBranch.BranchName = "Vashi";

vashiBranch.ShowBankDetails();