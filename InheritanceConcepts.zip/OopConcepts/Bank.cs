﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopConcepts
{
    internal class Bank
    {
        public string BankName { get; set; }

        public string BranchName;

        public void ShowBankDetails()
        {
            Console.WriteLine($"{BankName} -  {BranchName}");
        }
    }
}
