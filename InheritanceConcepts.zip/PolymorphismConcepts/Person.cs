﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismConcepts
{
    internal abstract class Person
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public void PunchIn()
        {
            Console.WriteLine($"{FirstName} {LastName} punched in.");
        }

        public void PunchOut()
        {
            Console.WriteLine($"{FirstName} {LastName} punched out.");
        }

        public virtual double GetLoan(double requestedAmount)
        {
            return requestedAmount;
        }

        public double CalculateBonus()
        {
            return 1000;
        }
    }
}
