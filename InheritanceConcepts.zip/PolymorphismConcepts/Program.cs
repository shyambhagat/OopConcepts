﻿// See https://aka.ms/new-console-template for more information

using PolymorphismConcepts;

Console.WriteLine("Hello, World!");

var contractor = new Contractor();
var employee = new Employee();
employee.Salary = 400000;

//Console.WriteLine(contractor.GetLoan(10000));
//Console.WriteLine(employee.GetLoan(100000));

Console.WriteLine(employee.CalculateBonus());
Console.WriteLine(contractor.CalculateBonus());
