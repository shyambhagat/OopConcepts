﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismConcepts
{
    internal sealed class Employee : Person
    {
        public string Designation { get; set; }
        public double Salary { get; set; }

        public override double GetLoan(double requestedAmount)
        {
            if (requestedAmount > (Salary * (double)20 / 100))
            {
                return Salary * (double)20 / 100;
            }

            return requestedAmount;
        }

        public new double CalculateBonus()
        {
            return 5000;
        }

        public double CalculateBonus(double percentage)
        {
            return Salary * (percentage / 100);
        }

        public double CalculateBonus(double percentage, double additionalAmount)
        {
            return (Salary * (percentage / 100)) + additionalAmount;
        }

        public double CalculateBonus(double fixedAmount, int yearsOfService)
        {
            return fixedAmount * yearsOfService;
        }
    }
}
