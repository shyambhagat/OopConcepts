﻿// See https://aka.ms/new-console-template for more information

using EncapsulationConcepts;

Console.WriteLine("Hello, World!");

var branch = new Branch();

var bank = new Bank();

