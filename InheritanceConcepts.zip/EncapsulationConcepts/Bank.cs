﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankOperations;

namespace EncapsulationConcepts
{
    internal class Bank
    {
        private double BankBalance { get; set; }
        public string BankName { get; set; }

        
        public void ShowBankDetails()
        {
            var bankOperations = new AllBankOperations();
            bankOperations.CalculateExpenses();

            Console.WriteLine($"{BankName}");
        }

        protected double GetBankBalance()
        {
            return BankBalance;
        }
    }
}
