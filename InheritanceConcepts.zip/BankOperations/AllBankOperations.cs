﻿namespace BankOperations
{
    public class AllBankOperations
    {
        private void CalculateTotal()
        {
            Console.WriteLine("Calculating Total");
        }

        internal void CalculateSalary()
        {
            Console.WriteLine("Calculating Total");
        }

        public void CalculateExpenses()
        {
            Console.WriteLine("Calculating Total");
        }


    }
}
