﻿namespace BankOperations;

public class BranchOperations
{
    public void PerformBranchOperations()
    {
        var bankOperations = new AllBankOperations();
        bankOperations.CalculateSalary();
    }
}